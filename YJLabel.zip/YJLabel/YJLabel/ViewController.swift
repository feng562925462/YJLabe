//
//  ViewController.swift
//  YJLabel
//
//  Created by 冯垚杰 on 2017/1/12.
//  Copyright © 2017年 冯垚杰. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var label: YJLabel!

    override func viewDidLoad() {
        super.viewDidLoad()
  
        
        label.topicTapHandle = { (label,topic, range) in
            print("\(label),\(topic),\(range)")
        }
        
        label.nickTapHandle = {(label,nick,range) in
            print("\(label),\(nick),\(range)")
        }
        label.linkTapHandle = {(label,link,range) in
            print("\(label),\(link),\(range)")
        }
        
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        label.text = "作者:@coderwhy 话题:#Label字符串识别# 网址:http://www.520it.com作者:@coderwhy 话题:#Label字符串识别# 网址:http://www.520it.com 作者:@coderwhy 话题:#Label字符串识别# 网址:http://www.520it.com作者:@coderwhy 话题:#Label字符串识别# 网址:http://www.520it.com作者:@coderwhy 话题:#Label字符串识别##Label字符串识别# #Label字符串识别# #Label字符串识别# #Label字符串识别# #Label字符串识别# 33#Label字符串识别#  网址:http://www.520it.com"
    }
}

