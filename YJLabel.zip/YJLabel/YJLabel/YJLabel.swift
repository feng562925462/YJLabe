//
//  YJLabel.swift
//  YJLabel
//
//  Created by 冯垚杰 on 2017/1/12.
//  Copyright © 2017年 冯垚杰. All rights reserved.
//

import UIKit

// 文本点击类型
enum YJTextTapType : Int {
    case none = 0 // 其他
    case nick     // @用户
    case topic    // 话题 ##
    case link     // url
}

class YJLabel: UILabel {

    override var text: String? {
        didSet {
            prepareText()
        }
    }
    override var attributedText: NSAttributedString? {
        didSet {
            prepareText()
        }
    }
    
    override var font: UIFont!{
        didSet {
            prepareText()
        }
    }
    
    override var textColor: UIColor!{
        didSet {
            prepareText()
        }
    }
    
    /// 匹配内容的颜色
    var matchTextColor = UIColor.blue {
        didSet {
        prepareText()
        }
    }
    
    fileprivate lazy var textStorage = NSTextStorage() /// NSMutableAttributeString的子类
    fileprivate lazy var layoutManager = NSLayoutManager() /// 布局管理者
    fileprivate lazy var textContainer = NSTextContainer()  /// 容器，需要设置大小
    
    /// 记录匹配的下标
   fileprivate lazy var linkRangs = [NSRange]()
   fileprivate lazy var nickRangs = [NSRange]()
   fileprivate lazy var topicRangs = [NSRange]()
    
    /** 记录用户选中的range */
    fileprivate var selectedRange : NSRange?
    
    // 用户点击还是松开
   fileprivate var isSelected = false
    
    // 点击类型
   fileprivate var tapType = YJTextTapType.none
    
    // 点击回调
    typealias YJTapTypeHandle = (YJLabel, String ,NSRange) -> Void
    
    var linkTapHandle : YJTapTypeHandle?
    var nickTapHandle : YJTapTypeHandle?
    var topicTapHandle : YJTapTypeHandle?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        preparetextSystem()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        preparetextSystem()
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        // 设置容器的大小为label的尺寸
        textContainer.size = frame.size
    }
    
    override func drawText(in rect: CGRect) {
        // 绘制点击的背景
        if let selectedRange = selectedRange {
            let selectedColor = isSelected ? UIColor(white: 0.7, alpha: 0.2) : UIColor.clear
            // 设置颜色
            textStorage.addAttribute(NSBackgroundColorAttributeName, value: selectedColor, range: selectedRange)
            // 绘制背景
            layoutManager.drawBackground(forGlyphRange: selectedRange, at: CGPoint(x: 0, y: 0))
        }
        // 绘制字形
        
        let range = NSRange(location: 0, length: textStorage.length)
        layoutManager.drawGlyphs(forGlyphRange: range, at: CGPoint())
    }
    
}

// MARK:- 文本系统处理
extension YJLabel {
    
   fileprivate func preparetextSystem() {
        // 准备文本
        prepareText()
    
        // 将布局添加到storeage中
        textStorage.addLayoutManager(layoutManager)
        
        //将容器添加到布局中
        layoutManager.addTextContainer(textContainer)
        
        // 开启用户交互
    
        isUserInteractionEnabled = true
        
        // 设置间距为0
        textContainer.lineFragmentPadding = 0
    }
    
    fileprivate func prepareText() {
        // 准备字符串
        var attString : NSAttributedString?
        if attributedText != nil {
            attString = attributedText
        } else {
            attString = NSAttributedString(string: text ?? "")
        }
        
        // 设置换行模型
        let attrStringM = addLineBreak(attString!)
        
        attrStringM.addAttribute(NSFontAttributeName, value: font, range: NSRange(location: 0, length: attrStringM.length))
        
        // 设置textstorage内容
        textStorage.setAttributedString(attrStringM)
        
        // 匹配url
        if let linkRangs = getLinkRanges() {
            self.linkRangs = linkRangs
            
            for range in linkRangs {
                textStorage.addAttribute(NSForegroundColorAttributeName, value: matchTextColor, range: range)
            }
        }
        
        // 匹配用户 "@[\\u4e00-\\u9fa5a-zA-Z0-9_-]*"
        if let nickRangs = getRangs("@.*?:") {
            self.nickRangs = nickRangs
            for range in nickRangs {
                textStorage.addAttribute(NSForegroundColorAttributeName, value: matchTextColor, range: range)
            }
        }
        
        // 匹配话题
        if let topicRangs = getRangs("#.*?#") {
            self.topicRangs = topicRangs
            for range in topicRangs {
                textStorage.addAttribute(NSForegroundColorAttributeName, value: matchTextColor, range: range)
            }
        }
        
        setNeedsDisplay()
    }

}

// MARK:- 正则匹配字符串
extension YJLabel {
    // 根据规则匹配出所有的字符串range
   fileprivate func getRangs(_ pattern : String) -> [NSRange]? {
        
        guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else {
            return nil
        }
        return getRangesFromResult(regex)
    }
    
    func getLinkRanges() -> [NSRange]? {
        
        guard let detector = try? NSDataDetector(types: NSTextCheckingTypes(NSTextCheckingResult.CheckingType.link.rawValue)) else {
            return nil
        }
        return getRangesFromResult(detector)
    }
    
    func getRangesFromResult(_ regex : NSRegularExpression) -> [NSRange]? {
        let results = regex.matches(in: textStorage.string, options: [], range: NSRange(location: 0, length: textStorage.length))
        var ranges = [NSRange]()
        
        for res in results {
            ranges.append(res.range)
        }
        return ranges
    }
}

// MARK:- 点击事件处理
extension YJLabel {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        // 记录点击
        isSelected = true
        
        // 获取用户点击的点
        if let selectedPoint = touches.first?.location(in: self) {
            // 获取该点所在的字符串range
            selectedRange = getSelectedRang(selectedPoint)
            
            // 根据点击的位置判读是否处理
            if selectedRange == nil {
                super.touchesBegan(touches, with: event)
            }
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard selectedRange != nil else {
            super.touchesEnded(touches, with: event)
            return
        }
        
        // 记录松开
        isSelected = false
        
        // 重新绘制
        setNeedsDisplay()
        
        // 取出内容
        let content = (textStorage.string as NSString).substring(with: selectedRange!)
        
        // 事件处理
        switch tapType {
        case .link:
            if let linkTapHandle = linkTapHandle {
                linkTapHandle(self, content, selectedRange!)
            }
        case .nick:
            if let nickTapHandle = nickTapHandle {
                nickTapHandle(self, content, selectedRange!)
            }
        case .topic:
            if let topicTapHandle = topicTapHandle {
                topicTapHandle(self, content, selectedRange!)
            }
        default:
            break
        }
    }
    
    fileprivate func getSelectedRang(_ selectedPoint : CGPoint) -> NSRange? {
        
        // 判断属性字符串是否为空
        guard textStorage.length != 0 else {
            return nil
        }
        
        // 获取选中点所在额下标
        let index = layoutManager.glyphIndex(for: selectedPoint, in: textContainer)
        
        // 判断下标的范围
        
        // 判断下标是否在url内
        for range in linkRangs {
            if index > range.location && index < range.location + range.length {
                setNeedsDisplay()
                tapType = .link
                return range
            }
        }
        
        // 判断下标是否在用户内
        
        for range in nickRangs {
            if index > range.location && index < range.location + range.length {
                setNeedsDisplay()
                tapType = .nick
                return range
            }
        }
        
        // 判断是否在话题内
        for range in topicRangs {
            if index > range.location && index < range.location + range.length {
                setNeedsDisplay()
                tapType = .topic
                return range
            }
        }
        return nil
    }
}

extension YJLabel {
    
    /// 如果用户没有设置lineBreak，所有内容会被绘制到同一行中，所以需要主动设置
    ///
    /// - Parameter attrString: <#attrString description#>
    /// - Returns: <#return value description#>
   fileprivate func addLineBreak(_ attrString : NSAttributedString) -> NSMutableAttributedString {
        
        let attrStringM = NSMutableAttributedString(attributedString: attrString)
        
        guard attrStringM.length != 0 else {
            return attrStringM
        }
        
        var range = NSRange()
        
        var attributes = attrStringM.attributes(at: 0, effectiveRange: &range)
        var paragraphStyle = attributes[NSParagraphStyleAttributeName] as? NSMutableParagraphStyle
        
        if let paragraphStyle = paragraphStyle{
            paragraphStyle.lineBreakMode = .byWordWrapping
        } else {
            paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle?.lineBreakMode = .byCharWrapping
            attributes[NSParagraphStyleAttributeName] = paragraphStyle
            
            attrStringM.addAttributes(attributes, range: range)
        }
        return attrStringM
    }
}
